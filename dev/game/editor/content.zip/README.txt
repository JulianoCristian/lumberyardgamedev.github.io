This is a test mod and you cannot change the life sprite (spr_life.png).
you may remove the readme.txt file but leave the rest!